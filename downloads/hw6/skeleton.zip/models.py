import torch.nn as nn
from torch.autograd import Variable
import torch
import torch.nn.functional as F


class CharRNNClassify(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        pass

    def forward(self, input, hidden=None):
        pass

    def init_hidden(self):
        pass
